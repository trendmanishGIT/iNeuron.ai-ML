WTF_CSRF_ENABLED = True #  activates the cross-site request forgery prevention 
SECRET_KEY = 'you-will-never-guess' # create cryptographic token to validate a form
SEND_FILE_MAX_AGE_DEFAULT = 0
