# Movie-Recommender-System
This is a hollywood movie recommender system built with Python. I used IMDB 5000 Movie Dataset to built this.
Link to dataset :- https://www.kaggle.com/carolzhangdc/imdb-5000-movie-dataset

Link to the web application :- https://recommendor-system.herokuapp.com/

I also wrote a blog about this project which help you understand the overall process :- https://www.academyofdatascience.com/blog-by-prashant/

I used Flask web framework in built in Python to put in on web.

# Files Brief
In the preprocessing.ipynb file the Data Preprocessing part has been done. 

In the create.py file I created two files for future uses one data.csv and other a numpy matrix.

The application is run from the main.py file.
